public class ExcepcionPrueba extends Exception{

    public ExcepcionPrueba(){

        super("No se han podido cargar los contactos");

    }
}
